package com.yuanyu.webSocket.controller;

//@Controller
//public class NavigationController {
//    // http://localhost:8084/websocket
//    @GetMapping("/websocket")
//    public String socket(){
//        return "websocket";
//    }
//}

//@Controller
//public class NavigationController {
//
//    // http://localhost:8084/websocket
//    @GetMapping("/websocket")
//    public ModelAndView socket(){
//        return new ModelAndView("/WEB-INF/views/websocket.jsp");
//    }
//}
